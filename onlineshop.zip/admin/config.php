<?php
// HTTP
define('HTTP_SERVER', 'http://www.butuhklik.com/admin/');
define('HTTP_CATALOG', 'http://www.butuhklik.com/');

// HTTPS
define('HTTPS_SERVER', 'http://www.butuhklik.com/admin/');
define('HTTPS_CATALOG', 'http://www.butuhklik.com/');

// DIR
define('DIR_APPLICATION', '/home/tkttdpgp/public_html/admin/');
define('DIR_SYSTEM', '/home/tkttdpgp/public_html/system/');
define('DIR_IMAGE', '/home/tkttdpgp/public_html/image/');
define('DIR_LANGUAGE', '/home/tkttdpgp/public_html/admin/language/');
define('DIR_TEMPLATE', '/home/tkttdpgp/public_html/admin/view/template/');
define('DIR_CONFIG', '/home/tkttdpgp/public_html/system/config/');
define('DIR_CACHE', '/home/tkttdpgp/public_html/system/storage/cache/');
define('DIR_DOWNLOAD', '/home/tkttdpgp/public_html/system/storage/download/');
define('DIR_LOGS', '/home/tkttdpgp/public_html/system/storage/logs/');
define('DIR_MODIFICATION', '/home/tkttdpgp/public_html/system/storage/modification/');
define('DIR_UPLOAD', '/home/tkttdpgp/public_html/system/storage/upload/');
define('DIR_CATALOG', '/home/tkttdpgp/public_html/catalog/');

// DB
define('DB_DRIVER', 'mysqli');
define('DB_HOSTNAME', 'localhost');
define('DB_USERNAME', 'tkttdpgp_ocar892');
define('DB_PASSWORD', ']771]P5yAS');
define('DB_DATABASE', 'tkttdpgp_ocar892');
define('DB_PORT', '3306');
define('DB_PREFIX', 'ocwm_');
