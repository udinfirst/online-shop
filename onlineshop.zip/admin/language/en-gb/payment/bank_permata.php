<?php
// Heading
$_['heading_title']		 = 'Permata Bank';

// Text
$_['text_payment']		 = 'Payment';
$_['text_success']		 = 'Success: You have modified Permata Bank details!';
$_['text_edit']          = 'Edit Permata Bank';

// Entry
$_['entry_bank']		 = 'Permata Bank Instructions';
$_['entry_total']		 = 'Total';
$_['entry_order_status'] = 'Order Status';
$_['entry_geo_zone']	 = 'Geo Zone';
$_['entry_status']		 = 'Status';
$_['entry_sort_order']	 = 'Sort Order';

// Help
$_['help_total']		 = 'The checkout total the order must reach before this payment method becomes active.';

// Error
$_['error_permission']   = 'Warning: You do not have permission to modify payment Permata Bank!';
$_['error_bank']         = 'Permata Bank Instructions Required!';